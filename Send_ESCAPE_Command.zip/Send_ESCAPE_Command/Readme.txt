../Code../SCardAPI_E - Source code using to build lib
../Code../SCard_dlg  - Demo code
Lib - include static library and dynamic library
Bin - Binary file