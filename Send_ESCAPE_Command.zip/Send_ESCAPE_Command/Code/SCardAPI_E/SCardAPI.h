#ifndef _SCARDAPI_H_
#define _SCARDAPI_H_

#include "windows.h"
#include "winscard.h"


#if 1
#define CARDAPI  extern "C" __declspec(dllexport)
#else
#define CARDAPI  extern "C" __declspec(dllimport)
#endif

//Get device list
CARDAPI DWORD SCListDevice(OUT char *szDeviceName,OUT unsigned long *pulDeviceNameLen);

//Connect device
CARDAPI DWORD SCConnect(IN const char* pPID, IN const char *szDeviceName, OUT HANDLE *phDevHandle);

//Disconnect with reader
CARDAPI DWORD SCDisconnect(IN HANDLE hDevHandle);


//Send command to reader
CARDAPI DWORD SCTransmit(IN HANDLE hDevHandle, IN const unsigned char *pbSendBuff, IN unsigned long ulSendLen,
						 OUT unsigned char *pbRecBuff, IN OUT unsigned long *pulRecLen);

//Error message
CARDAPI DWORD SCGetErrMsg(IN unsigned long ulErrCode, OUT char *szErrMsg, IN OUT unsigned long *pulMsgLen);

//Set register key
DWORD SCSetRegKey(IN const char* pPID);

//Reconnect reader
DWORD SCReConnect(IN HANDLE hDevHandle) ;

#endif