// SCardAPI_Expand.cpp : Define DLL 
//

#include "stdafx.h"
#include "SCardAPI.h"
#include "stdio.h"
#include <Setupapi.h>

#pragma comment(lib, "Winscard.lib")
#pragma comment(lib, "setupapi.lib")


#define SCARD_PROTOCOL_0				0		 
#define NUMBER_OF_READERS				1
#define MAX_RESPONSE					100
#define NAME_LENGTH						100
#define READER_LIST_BUF_MAXLEN			1000
#define SCARD_STATE_FIND				0x10000000

#define IOCTL_CCID_ESCAPE SCARD_CTL_CODE(3500)


SCARDCONTEXT		 ContextHandle;			
SCARD_READERSTATE	 NewReaderState;		
int		ReaderNum = 0 ;							
char	ConnectReaderFlag;						
DWORD	ActiveProtocol ;
SCARDHANDLE	  CardHandle;     // Card handle

const unsigned char APDU_REQ_Header[3] = {0xa5, 0x5a, 0x31};

//List device
DWORD SCListDevice(OUT char *szDeviceName, OUT unsigned long *pulDeviceNameLen)
{

	BYTE	ResponseBuffer[READER_LIST_BUF_MAXLEN];  
	DWORD	ResponseLength;							 

	memset( ResponseBuffer, 0x00, READER_LIST_BUF_MAXLEN);

	ResponseLength = READER_LIST_BUF_MAXLEN;
	ConnectReaderFlag = 0;							


	DWORD ret = SCardEstablishContext(SCARD_SCOPE_USER, NULL, NULL, &ContextHandle);
	if (ret != SCARD_S_SUCCESS)
	{
		NewReaderState.dwCurrentState = 0;
		return ret ;
	}

	ret = SCardListReaders(ContextHandle, 0, (char *)ResponseBuffer, &ResponseLength); 
	ReaderNum = 0;
	if (ret == SCARD_S_SUCCESS)
	{
		ReaderNum = 1;
		memcpy(szDeviceName, ResponseBuffer, ResponseLength) ;
		*pulDeviceNameLen = (unsigned long)ResponseLength ;  
	}

	return ret ;
}

//Connect to device
DWORD SCConnect(IN const char* pPID, IN const char *szDeviceName, OUT HANDLE *phDevHandle)
{

	DWORD	ret = 0 ;

	if(ReaderNum == 0)   // no reader
	{ 
		ConnectReaderFlag = 0;  
		NewReaderState.dwCurrentState = 0;  // haven't found reader
		return -1 ;
	}
	else  
	{
		{  
			NewReaderState.dwCurrentState = SCARD_STATE_FIND;  // Flag using to tell the reader found
			// Connect reader with card
			//ret = SCardConnect(ContextHandle, szDeviceName, SCARD_SHARE_EXCLUSIVE, 
			//            SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1, &CardHandle, &ActiveProtocol);
			//
			// Connect reader without card
			ret = SCardConnect(ContextHandle, szDeviceName, SCARD_SHARE_DIRECT, 0, &CardHandle, &ActiveProtocol);
			if (ret == SCARD_S_SUCCESS) 
			{
			
				SCSetRegKey(pPID) ;
				SCReConnect((HANDLE)CardHandle) ;
				*phDevHandle = (HANDLE)CardHandle ;
				ConnectReaderFlag = 1;  // Flag means connect to reader
				return ret ;
			}
			else
			{
				ConnectReaderFlag = 0;  // Flag means the reader has disconnect
				return ret ;
			}
		}

	}   // How many reader found?

}

//Disconnect reader
DWORD SCDisconnect(IN HANDLE hDevHandle)
{
	int ret = SCardDisconnect((SCARDCONTEXT)hDevHandle, SCARD_LEAVE_CARD);
	ret = SCardReleaseContext(ContextHandle);
	ConnectReaderFlag = 0 ;
	ContextHandle = NULL ;
	return ret ;
}

DWORD SCReConnect(IN HANDLE hDevHandle)
{
	return SCardReconnect((SCARDHANDLE)hDevHandle,
		SCARD_SHARE_SHARED,
		SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,
		SCARD_LEAVE_CARD,
		&ActiveProtocol );

}



//Send command to reader
DWORD SCTransmit(IN HANDLE hDevHandle, IN const unsigned char *pbSendBuff, IN unsigned long ulSendLen,
						 OUT unsigned char *pbRecBuff, IN OUT unsigned long *pulRecLen)
{
	char sbuf[128] = { 0 } ;
	DWORD dwControlCode = IOCTL_CCID_ESCAPE;
	unsigned char  RecvBuffer[512] = { 0 } ;
	unsigned long RecvBufferLength = 512;

	if ( !ConnectReaderFlag)
	{
		return -1;
	}
	int ret = SCardControl((SCARDHANDLE)hDevHandle, dwControlCode, pbSendBuff, ulSendLen, RecvBuffer, RecvBufferLength, &RecvBufferLength);
	if((ret == SCARD_S_SUCCESS) && (RecvBufferLength >= 1))
	{
		//Verfiy response data
		//if((RecvBuffer[RecvBufferLength-2] != 0x90) || (RecvBuffer[RecvBufferLength-1] != 0x00))   return 1;
		if (*pulRecLen <= RecvBufferLength)
		{
			return SCARD_E_INSUFFICIENT_BUFFER ;
		}

		memcpy(pbRecBuff, RecvBuffer, RecvBufferLength) ;
		*pulRecLen = RecvBufferLength ;

		return ret;
	}

	return ret ;
}




//Set register key
DWORD SCSetRegKey(IN const char* pPID)
{
	int   index=0; 
	char  name[256];
	char  subkey[256];
	HKEY  m_key; 
	int ret = -1;
	
	DWORD dwVersion = GetVersion();
	
	// Get the Windows version.
	
	DWORD dwWindowsMajorVersion =  (DWORD)(LOBYTE(LOWORD(dwVersion)));
	DWORD dwWindowsMinorVersion =  (DWORD)(HIBYTE(LOWORD(dwVersion)));
	
	char path[64];
	sprintf(path,"SYSTEM\\CurrentControlSet\\Enum\\USB\\VID_096E&PID_%s",pPID);
	
	ret = RegOpenKey(HKEY_LOCAL_MACHINE,path, &m_key); 
	if(ret != ERROR_SUCCESS)
			goto end;
	
	while(RegEnumKey(m_key,index,name,64)==ERROR_SUCCESS) 
	{ 
		
		if (dwWindowsMajorVersion == 6 && dwWindowsMinorVersion == 1)
		{
			//Win 7
			sprintf(subkey,"%s\\%s\\Device Parameters\\WUDFUsbccidDriver",path,name);
		}
		else 
		{  
			sprintf(subkey,"%s\\%s\\Device Parameters",path,name);
		}

		HKEY hKey;
		DWORD dwDisposition;
		DWORD retvalue =0x00;
		DWORD value =0x01;
		long temp = KEY_ALL_ACCESS;
		DWORD value_resile = sizeof(DWORD);   
		DWORD type_1=REG_DWORD;
		
		
		ret = RegOpenKey(HKEY_LOCAL_MACHINE,subkey, &hKey); 
		if(ret != ERROR_SUCCESS)
			goto end;
		
		ret = RegQueryValueEx(hKey, "EscapeCommandEnable",0L, &type_1,(unsigned char*)&retvalue,&value_resile);
		if (ret!=ERROR_SUCCESS)
		{
			ret = RegCreateKeyEx(HKEY_LOCAL_MACHINE,subkey,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,&dwDisposition);
			if(ret != ERROR_SUCCESS)
				goto end;
	
			ret=RegSetValueEx(hKey,"EscapeCommandEnable",0,REG_DWORD,(unsigned char*)&value,4);
			if(ret != ERROR_SUCCESS)
				goto end;
			else 
			{
				if (ret != SCARD_S_SUCCESS)
				{
					RegCloseKey(hKey);
					return -1 ;
				}
			}
		} 
		else
		{
			if (retvalue != 0x01)
			{
				ret=RegSetValueEx(hKey,"EscapeCommandEnable",0,REG_DWORD,(unsigned char*)&value,4);
				if(ret != ERROR_SUCCESS)
					goto end;
			}
			
		}
		RegCloseKey(hKey);
		index++;
	} 
	
end:
	if(m_key != NULL)
		RegCloseKey(m_key);
	return ret;
}

//Error message
DWORD SCGetErrMsg(IN unsigned long ulErrCode, OUT char *szErrMsg, IN OUT unsigned long *pulMsgLen)
{
	
	char ErrorMessage[512] = {0} ;
	switch (ulErrCode) {
		case SCARD_E_CANCELLED:
				strcpy(ErrorMessage,"The action was cancelled by an SCardCancel request.");
				break;
		case SCARD_E_CANT_DISPOSE:
				strcpy(ErrorMessage,"The system could not dispose of the media in the requested manner.");
				break;
		case SCARD_E_CARD_UNSUPPORTED:
				strcpy(ErrorMessage,"The smart card does not meet minimal requirements for support.");
				break;
		case SCARD_E_DUPLICATE_READER:
				strcpy(ErrorMessage,"The reader driver didn't produce a unique reader name.");
				break;
		case SCARD_E_INSUFFICIENT_BUFFER:
				strcpy(ErrorMessage,"The data buffer to receive returned data is too small for the returned data.");
				break;
		case SCARD_E_INVALID_ATR:
				strcpy(ErrorMessage,"An ATR obtained from the registry is not a valid ATR string.");
				break;
		case SCARD_E_INVALID_HANDLE:
				strcpy(ErrorMessage,"The supplied handle was invalid.");
				break;
		case SCARD_E_INVALID_PARAMETER:
				strcpy(ErrorMessage,"One or more of the supplied parameters could not be properly interpreted.");
				break;
		case SCARD_E_INVALID_TARGET:
				strcpy(ErrorMessage,"Registry startup information is missing or invalid.");
				break;
		case SCARD_E_INVALID_VALUE:
				strcpy(ErrorMessage,"One or more of the supplied parameters?values could not be properly interpreted.");
				break;
		case SCARD_E_NOT_READY:
				strcpy(ErrorMessage,"The reader or card is not ready to accept commands.");
				break;
		case SCARD_E_NOT_TRANSACTED:
				strcpy(ErrorMessage,"An attempt was made to end a non-existent transaction.");
				break;
		case SCARD_E_NO_MEMORY:
				strcpy(ErrorMessage,"Not enough memory available to complete this command.");
				break;
		case SCARD_E_NO_SERVICE:
				strcpy(ErrorMessage,"The Smart card resource manager is not running.");
				break;
		case SCARD_E_NO_SMARTCARD:
				strcpy(ErrorMessage,"The operation requires a smart card but no smart card is currently in the device.");
				break;
		case SCARD_E_PCI_TOO_SMALL:
				strcpy(ErrorMessage,"The PCI Receive buffer was too small.");
				break;
		case SCARD_E_PROTO_MISMATCH:
				strcpy(ErrorMessage,"The requested protocols are incompatible with the protocol currently in use with the card.");
				break;
		case SCARD_E_READER_UNAVAILABLE:
				strcpy(ErrorMessage,"The specified reader is not currently available for use.");
				break;
		case SCARD_E_READER_UNSUPPORTED:
				strcpy(ErrorMessage,"The reader driver does not meet minimal requirements for support.");
				break;
		case SCARD_E_SERVICE_STOPPED:
				strcpy(ErrorMessage,"The Smart card resource manager has shut down.");
				break;
		case SCARD_E_SHARING_VIOLATION:
				strcpy(ErrorMessage,"The card cannot be accessed because of other connections outstanding.");
				break;
		case SCARD_E_SYSTEM_CANCELLED:
				strcpy(ErrorMessage,"The action was cancelled by the system presumably to log off or shut down.");
				break;
		case SCARD_E_TIMEOUT:
				strcpy(ErrorMessage,"The user-specified timeout value has expired.");
				break;
		case SCARD_E_UNKNOWN_CARD:
				strcpy(ErrorMessage,"The specified card name is not recognized.");
				break;
		case SCARD_E_UNKNOWN_READER:
				strcpy(ErrorMessage,"The specified reader name is not recognized.");
				break;
		case SCARD_F_COMM_ERROR:
				strcpy(ErrorMessage,"An internal communications error has been detected.");
				break;
		case SCARD_F_INTERNAL_ERROR:
				strcpy(ErrorMessage,"An internal consistency check failed.");
				break;
		case SCARD_F_UNKNOWN_ERROR:
				strcpy(ErrorMessage,"An internal error has been detected but the source is unknown.");
				break;
		case SCARD_F_WAITED_TOO_LONG:
				strcpy(ErrorMessage,"An internal consistency timer has expired.");
				break;
		case SCARD_S_SUCCESS:
				strcpy(ErrorMessage,"OK");
				break;
		case SCARD_W_REMOVED_CARD:
				strcpy(ErrorMessage,"The card has been removed so that further communication is not possible.");
				break;
		case SCARD_W_RESET_CARD:
				strcpy(ErrorMessage,"The card has been reset so any shared state information is invalid.");
				break;
		case SCARD_W_UNPOWERED_CARD:
				strcpy(ErrorMessage,"Power has been removed from the card so that further communication is not possible.");
				break;
		case SCARD_W_UNRESPONSIVE_CARD:
				strcpy(ErrorMessage,"The card is not responding to a reset.");
				break;
		case SCARD_W_UNSUPPORTED_CARD:
				strcpy(ErrorMessage,"The reader cannot communicate with the card due to ATR configuration conflicts.");
				break;
		default:
		strcpy(ErrorMessage, "Unknown error code.");
		break;
		}
	
	*pulMsgLen = strlen(ErrorMessage) ;
	memcpy(szErrMsg, ErrorMessage, *pulMsgLen) ;
	return *pulMsgLen ;
}