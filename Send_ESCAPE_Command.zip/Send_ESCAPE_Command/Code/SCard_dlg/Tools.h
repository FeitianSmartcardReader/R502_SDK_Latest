#ifndef _TOOLS_H_
#define _TOOLS_H_

#include "stdio.h"
#include "windows.h"

int Hex2Asc(char *Dest,char *Src,int SrcLen);

int Asc2Hex(char *Dest,char *Src,int SrcLen);

#endif
