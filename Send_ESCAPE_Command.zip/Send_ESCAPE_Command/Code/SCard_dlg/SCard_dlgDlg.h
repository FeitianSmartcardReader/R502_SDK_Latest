// SCard_dlgDlg.h : header file
//

#if !defined(AFX_SCARD_DLGDLG_H__BD2ECC35_9BE3_47EF_90B5_48C1546E59C6__INCLUDED_)
#define AFX_SCARD_DLGDLG_H__BD2ECC35_9BE3_47EF_90B5_48C1546E59C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "SCardAPI.h"

/////////////////////////////////////////////////////////////////////////////
// CSCard_dlgDlg dialog

class CSCard_dlgDlg : public CDialog
{
// Construction
public:
	void OnRefresh();
	CSCard_dlgDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSCard_dlgDlg)
	enum { IDD = IDD_SCARD_DLG_DIALOG };
	CString	m_Req;
	CString	m_sPID;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSCard_dlgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSCard_dlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonConnect();
	afx_msg void OnButtonCommand();
	afx_msg void OnButtonDisconnect();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	CComboBox* m_pCtl;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCARD_DLGDLG_H__BD2ECC35_9BE3_47EF_90B5_48C1546E59C6__INCLUDED_)
