// SCard_dlg.h : main header file for the SCARD_DLG application
//

#if !defined(AFX_SCARD_DLG_H__15DAF4F3_892B_4770_ADB8_076B5D6A2036__INCLUDED_)
#define AFX_SCARD_DLG_H__15DAF4F3_892B_4770_ADB8_076B5D6A2036__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSCard_dlgApp:
// See SCard_dlg.cpp for the implementation of this class
//

class CSCard_dlgApp : public CWinApp
{
public:
	CSCard_dlgApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSCard_dlgApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSCard_dlgApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCARD_DLG_H__15DAF4F3_892B_4770_ADB8_076B5D6A2036__INCLUDED_)
